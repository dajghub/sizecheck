// popup.js — SizeCheck Extension · Popup (fallback manuel)
// Dépend de sizes.js (chargé avant)

const state = {
  sourceBrand: null,
  sourceSize: null,
  pageBrand: null
};

function renderBrandGrid() {
  const pageBrandName = state.pageBrand ? SC_BRANDS[state.pageBrand]?.name : null;
  document.getElementById('brand-grid').innerHTML = Object.entries(SC_BRANDS).map(([key, b]) => `
    <button class="brand-btn ${state.sourceBrand === key ? 'active' : ''}" data-action="brand" data-value="${key}">
      <img src="${b.logo}" alt="${b.name}" loading="lazy">
      <span class="bname">${b.name}</span>
    </button>
  `).join('');

  if (pageBrandName) {
    const existing = document.getElementById('page-brand-badge');
    if (!existing) {
      const badge = document.createElement('div');
      badge.id = 'page-brand-badge';
      badge.className = 'page-brand-badge';
      badge.textContent = `Page détectée : ${pageBrandName}`;
      document.getElementById('brand-grid').before(badge);
    }
  }
}

function renderStep2() {
  const container = document.getElementById('step2');
  if (!state.sourceBrand) { container.innerHTML = ''; return; }

  const sizesHTML = SC_ALL_SIZES.map(s => `
    <button class="size-btn ${state.sourceSize === s ? 'active' : ''}" data-action="size" data-value="${s}">${s}</button>
  `).join('');

  let resultsHTML = '';
  if (state.sourceSize) {
    const cm = scGetCm(state.sourceBrand, state.sourceSize);
    if (cm) {
      resultsHTML = Object.entries(SC_BRANDS)
        .filter(([key]) => key !== state.sourceBrand || key === state.pageBrand)
        .map(([key, b]) => ({ key, b, targetSize: scFindBestSize(key, cm) }))
        .sort((a, b) => {
          if (a.key === state.pageBrand) return -1;
          if (b.key === state.pageBrand) return 1;
          return Math.abs(b.targetSize - state.sourceSize) - Math.abs(a.targetSize - state.sourceSize);
        })
        .map(({ key, b, targetSize }) => {
          const delta = targetSize - state.sourceSize;
          const deltaLabel = delta > 0 ? `+${delta}` : delta < 0 ? `${delta}` : '';
          const deltaClass = delta > 0 ? 'up' : delta < 0 ? 'down' : 'none';
          const isPage = key === state.pageBrand;
          return `
            <div class="result-row ${isPage ? 'page-result' : ''}">
              <img class="result-logo" src="${b.logo}" alt="${b.name}" loading="lazy">
              <span class="result-name">${b.name}${isPage ? ' <span class="on-page-tag">cette page</span>' : ''}</span>
              <span class="fit-tag ${deltaClass}">${deltaLabel}</span>
              <span class="result-size">EU ${targetSize}</span>
            </div>
          `;
        }).join('');
    }
  }

  const srcBrand = SC_BRANDS[state.sourceBrand];

  container.innerHTML = `
    <div class="card">
      <div class="label">Ma pointure habituelle</div>
      <div class="size-grid">${sizesHTML}</div>
    </div>
    ${resultsHTML ? `
      <div class="card">
        <div class="label">Équivalences EU</div>
        <div class="results">${resultsHTML}</div>
      </div>
    ` : ''}
  `;
}

function render() {
  renderBrandGrid();
  renderStep2();
}

document.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-action]');
  if (!btn) return;
  const { action, value } = btn.dataset;

  if (action === 'brand') {
    state.sourceBrand = value;
    state.sourceSize = null;
    chrome.storage.local.set({ sc_source_brand: value });
    render();
  }

  if (action === 'size') {
    state.sourceSize = parseInt(value);
    render();
  }
});

// Init — détecter la marque de la page active, puis rendre
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  try {
    const host = new URL(tabs[0].url).hostname.replace(/^www\./, '');
    for (const [domain, brand] of Object.entries(SC_DOMAIN_MAP)) {
      if (host === domain || host.endsWith('.' + domain)) {
        state.pageBrand = brand;
        break;
      }
    }
  } catch (e) {}

  chrome.storage.local.get(['sc_source_brand'], (data) => {
    if (data.sc_source_brand) state.sourceBrand = data.sc_source_brand;
    render();
  });
});
